# Trigonometry Concept Book — HSC Higher Math Chapter 8

## Files
- `trigonometry-concept-book.html` — Open this file in any modern browser to read the book.
- `fonts/Alinur-Ekush.woff2` — Bangla font (Lipighors Alinur, subset).
- `fonts/Lora-400-700.woff2` — English/Latin font (regular + bold).
- `fonts/Lora-400-700-italic.woff2` — Lora italic.

## How to use
Just **double-click the HTML file** — it will open in your default browser (Chrome, Firefox, Edge, Safari). All fonts and KaTeX math rendering are loaded automatically. Internet is needed only for KaTeX (loaded from CDN); all other assets are local.

## Features
- 20 sections covering the full HSC Chapter 8 syllabus.
- Bangla in Lipighors Alinur, English in Lora, math in standard KaTeX.
- Interactive unit circle (drag the slider, watch sin/cos/tan update live).
- Animated sin/cos graph drawing (auto-plays on scroll-into-view).
- Interactive triangle (Sine rule demo).
- Degree ↔ Radian converter.
- 11 practice problems with collapsible solutions.
- 10 fully worked examples.
- 4 ASTC quadrant cards.
- Sticky TOC sidebar with active-section highlighting.
- Mobile responsive (sidebar collapses, hamburger menu).
- Scroll progress bar.

## License notes
- Alinur Ekush is a free font from lipighor.com — used here under their free license (commercial design allowed with optional credit). For webfont redistribution on a public website, contact lipighor.com for permission.
- Lora is licensed under the SIL Open Font License 1.1.
- KaTeX is MIT licensed.
